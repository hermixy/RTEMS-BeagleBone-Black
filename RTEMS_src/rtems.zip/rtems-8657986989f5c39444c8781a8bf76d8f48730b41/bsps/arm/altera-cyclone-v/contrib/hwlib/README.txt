HWLIB
=====
Hwlib is a collection of sources provided by Altera for the Cyclone-V.

As hwlib is third party software, please keep modifications and additions 
to the sources to a minimum for easy maintenance. Otherwise updating to a 
new version of hwlib released by Altera can become difficult.

The hwlib directory contains only those files from Alteras hwlib which are
required by the BSP (the whole hwlib was considered too big).
The directory structure within the hwlib directory is equivalent to Alteras
hwlib directory structure. For easy maintenance only whole files have been
left out.

Altera provides the hwlib with their SoC Embedded Design Suite (EDS).

HWLIB Version:
--------------
All files are from hwlib 13.1 distributed with SoC EDS 14.0.0.200.
