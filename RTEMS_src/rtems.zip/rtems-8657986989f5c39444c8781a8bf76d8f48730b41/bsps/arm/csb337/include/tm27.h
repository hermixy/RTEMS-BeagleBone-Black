/**
 *@file
 *
 *@ingroup RTEMSBSPsARMCSB337
 *
 *@brief Implementations of interrupt mechanisms for Time Test 27.
 *
 */

#include <rtems/tm27-default.h>
